-- Extensiones
create extension if not exists pgcrypto;
create extension if not exists btree_gist;

-- Tabla de perfiles
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  role text check (role in ('admin','therapist')) default 'therapist',
  phone text,
  created_at timestamptz default now()
);

-- Trigger para crear profile al registrarse
create or replace function public.handle_new_user()
returns trigger as $$
begin
  insert into public.profiles (id, full_name)
  values (new.id, split_part(new.email, '@', 1))
  on conflict (id) do nothing;
  return new;
end; $$ language plpgsql security definer;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- Pacientes
create table if not exists public.patients (
  id uuid primary key default gen_random_uuid(),
  therapist_id uuid not null references public.profiles(id) on delete cascade,
  full_name text not null,
  phone text,
  email text,
  notes text,
  created_at timestamptz default now()
);

-- Turnos
create table if not exists public.appointments (
  id uuid primary key default gen_random_uuid(),
  therapist_id uuid not null references public.profiles(id) on delete cascade,
  patient_id uuid references public.patients(id) on delete set null,
  start_at timestamptz not null,
  end_at timestamptz not null,
  status text check (status in ('scheduled','cancelled','no_show','blocked')) default 'scheduled',
  service text,
  note text,
  created_by uuid references public.profiles(id),
  created_at timestamptz default now()
);

-- Evitar solapamiento de turnos por terapeuta
alter table public.appointments add constraint if not exists appointments_no_overlap
exclude using gist (
  therapist_id with =,
  tstzrange(start_at, end_at, '[)') with &&
) where (status = 'scheduled');

-- Habilitar RLS
alter table public.profiles enable row level security;
alter table public.patients enable row level security;
alter table public.appointments enable row level security;

-- Policies
create policy if not exists profiles_select_all on public.profiles
for select using (true);

create policy if not exists patients_select_own on public.patients
for select using (auth.uid() = therapist_id);
create policy if not exists patients_mod_own on public.patients
for all using (auth.uid() = therapist_id) with check (auth.uid() = therapist_id);

create policy if not exists appt_select_own on public.appointments
for select using (auth.uid() = therapist_id);
create policy if not exists appt_mod_own on public.appointments
for all using (auth.uid() = therapist_id) with check (auth.uid() = therapist_id);

-- RPC: solo slots ocupados
create or replace function public.get_busy_slots(t_id uuid, day date)
returns table (start_at timestamptz, end_at timestamptz, status text)
language sql
security definer
set search_path = public
as $$
  select a.start_at, a.end_at, a.status
  from public.appointments a
  where a.therapist_id = t_id
    and a.status = 'scheduled'
    and a.start_at >= day::timestamptz
    and a.start_at < (day + 1)::timestamptz
  order by a.start_at asc;
$$;

revoke all on function public.get_busy_slots(uuid, date) from public;
grant execute on function public.get_busy_slots(uuid, date) to authenticated;
